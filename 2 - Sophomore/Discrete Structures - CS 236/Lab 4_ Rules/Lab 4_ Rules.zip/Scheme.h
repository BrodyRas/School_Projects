#ifndef Scheme_h
#define Scheme_h

#include <vector>
#include <string>

class Scheme : public std::vector<std::string> {

};

#endif /* Scheme_h */
