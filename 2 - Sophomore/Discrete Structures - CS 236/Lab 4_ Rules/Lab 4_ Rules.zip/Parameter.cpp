#include "Parameter.h"

using namespace std;

string Parameter::toString(){
  return value;
}
